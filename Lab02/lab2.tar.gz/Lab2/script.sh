#!/bin/bash

current_date=$(date)

echo "Current Date: $current_date"

current_time=$(date +%s)
let double_current_time=current_time*2

echo "Current Time: $current_time"
echo "Current Time x2: $double_current_time"

for i in {1..20}; do
	echo "Number: $i"
done
